steal(
    './controllers/main_controller',
    './models/main_model'
    );