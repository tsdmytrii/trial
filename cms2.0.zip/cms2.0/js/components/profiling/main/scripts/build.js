//steal/js cookbook/scripts/compress.js

load("steal/rhino/rhino.js");
steal('steal/build',
	  'steal/build/scripts',
	  'steal/build/styles',
	  'steal/build/apps').then(

	function(){

//                steal.build('components/user/core/scripts/build.html', {to: 'components/user/core/production', compressor: 'uglify'});
//
//                steal.build('components/user/main/scripts/build.html', {to: 'components/user/main/production', compressor: 'uglify'});
//
//                steal.build('components/user/main_ie/scripts/build.html', {to: 'components/user/main_ie/production', compressor: 'uglify'});
//
////                steal.build('components/user/account/scripts/build.html', {to: 'components/user/account/production', compressor: 'uglify'});
//
//                steal.build('components/user/article/scripts/build.html', {to: 'components/user/article/production', compressor: 'uglify'});
////
//                steal.build('components/user/articleitem/scripts/build.html', {to: 'components/user/articleitem/production', compressor: 'uglify'});
////
//                steal.build('components/user/contract/scripts/build.html', {to: 'components/user/contract/production', compressor: 'uglify'});
////
//                steal.build('components/user/contractitem/scripts/build.html', {to: 'components/user/contractitem/production', compressor: 'uglify'});
//
//                steal.build('components/user/newsonline/scripts/build.html', {to: 'components/user/newsonline/production', compressor: 'uglify'});
////
//                steal.build('components/user/newsonlineitem/scripts/build.html', {to: 'components/user/newsonlineitem/production', compressor: 'uglify'});
////
//                steal.build('components/user/question/scripts/build.html', {to: 'components/user/question/production', compressor: 'uglify'});
////
//                steal.build('components/user/search/scripts/build.html', {to: 'components/user/search/production', compressor: 'uglify'});
////
//                steal.build('components/user/static_comp/scripts/build.html', {to: 'components/user/static_comp/production', compressor: 'uglify'});
////
//                steal.build('components/user/static_comp_form/scripts/build.html', {to: 'components/user/static_comp_form/production', compressor: 'uglify'});
////
//                steal.build('components/user/reiting/scripts/build.html', {to: 'components/user/reiting/production', compressor: 'uglify'});
////
//                steal.build('components/user/trader/scripts/build.html', {to: 'components/user/trader/production', compressor: 'uglify'});
////
//                steal.build('components/user/site/scripts/build.html', {to: 'components/user/site/production', compressor: 'uglify'});
////
//                steal.build('components/user/calendar/scripts/build.html', {to: 'components/user/calendar/production', compressor: 'uglify'});


});
