/*
 * @page index Forex WebInnovativeLab
 * @tag home 
 *
 * ###Core information
 *  
 * It's our first documentation
 * Here we do have all descriptions to our core files: 
 * Let's take a lool on 
 * * Navigation 
 * * Realplexor
 * * Other plugins, which are loaded in Core
 */


