module("cookbook");

test("cookbook testing works", function(){
	ok(true,"an assert is run");
});