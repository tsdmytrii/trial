steal
  .plugins("funcunit/qunit", "cookbook")
  .then("cookbook_test");