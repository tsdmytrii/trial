steal(

    'css/plugins/windows-engine/jquery.windows-engine.css',
    '//resources/plugins/jquery.windows-engine.js',

    '//resources/plugins/jquery.fancybox/jquery.fancybox-1.3.4.js',
    '//resources/plugins/jquery.fancybox/jquery.fancybox-1.3.4.css',

    '//resources/plugins/jquery.synctranslit/jquery.synctranslit.js',

    '//resources/plugins/uploadify/jquery.uploadify.v2.1.4.js',
    '//resources/plugins/uploadify/uploadify.css',
    '//resources/plugins/uploadify/swfobject.js',

    //load resources
    './css/producer.css',

    './controllers/producers_controller',
    './models/producers_model',
    './controllers/producer_controller',
    './models/producer_model'

    );









