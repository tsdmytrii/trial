steal(

    'css/plugins/windows-engine/jquery.windows-engine.css',
    '//resources/plugins/jquery.windows-engine.js',

    '//resources/plugins/jquery.fancybox/jquery.fancybox-1.3.4.js',
    '//resources/plugins/jquery.fancybox/jquery.fancybox-1.3.4.css',

    '//resources/plugins/uploadify/jquery.uploadify.v2.1.4.js',
    '//resources/plugins/uploadify/uploadify.css',
    '//resources/plugins/uploadify/swfobject.js',

    '//components/admin/paginator/paginator.js',

    //load resources
    './css/product.css',

    './controllers/products_controller',
    './models/products_model',
    './controllers/product_controller',
    './models/product_model'

    );









