steal(
    '//css/plugins/datatables/demo_table.css',
    '//css/admin/menu/menu.css',
    'resources/plugins/datatables/jquery.dataTables.js',
    '//resources/plugins/jlinq/jlinq.js'
    )

.then(
    '//resources/plugins/ckeditor/adapters/jquery.js',
    './css/pages.css',
//    '//resources/plugins/ckeditor/styles.js',
    //then our component
    './controllers/pages_controller',
    './models/pages_model'
    );









