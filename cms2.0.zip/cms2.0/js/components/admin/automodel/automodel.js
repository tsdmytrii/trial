steal(

    'css/plugins/windows-engine/jquery.windows-engine.css',
    '//resources/plugins/jquery.windows-engine.js',

    '//resources/plugins/jquery.fancybox/jquery.fancybox-1.3.4.js',
    '//resources/plugins/jquery.fancybox/jquery.fancybox-1.3.4.css',

    '//resources/plugins/jquery.synctranslit/jquery.synctranslit.js',

    '//resources/plugins/uploadify/jquery.uploadify.v2.1.4.js',
    '//resources/plugins/uploadify/uploadify.css',
    '//resources/plugins/uploadify/swfobject.js',

    //load resources
    './css/automodel.css',

    './controllers/autogroup_controller',
    './models/autogroup_model',
    './controllers/automodels_controller',
    './models/automodels_model',
    './controllers/automodel_controller',
    './models/automodel_model',
    './controllers/complectation_controller',
    './models/complectation_model',
    './controllers/characteristic_controller',
    './models/characteristic_model'

    );









