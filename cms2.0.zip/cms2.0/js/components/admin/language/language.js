steal(

    'css/plugins/windows-engine/jquery.windows-engine.css',
    '//resources/plugins/jquery.windows-engine.js',

    //load resources
    './css/language.css',

    './controllers/languages_controller',
    './models/languages_model',
    './controllers/language_controller',
    './models/language_model'

    );









