steal('//components/admin/paginator/paginator.js')
.then(

    'css/plugins/windows-engine/jquery.windows-engine.css',
    '//resources/plugins/jquery.windows-engine.js',

    //load resources
    './css/component_type.css',
    './controllers/component_types_controller',
    './models/component_types_model',
    './controllers/component_type_controller',
    './models/component_type_model'

);