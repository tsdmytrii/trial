steal(
    '//resources/plugins/uploadify/jquery.uploadify.v2.1.4.js',
    '//resources/plugins/uploadify/swfobject.js',

    //load resources
    './css/img_banner.css',
    './controllers/img_banners_controller',
    './models/img_banners_model',
    './controllers/img_banner_controller',
    './models/img_banner_model'
    );









