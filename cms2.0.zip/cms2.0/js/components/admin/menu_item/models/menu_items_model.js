$.Model('Menu_items_model', {

    get_menu_item_by_block: function(data, success){
        $.ajax({
            url: base_url+'admin/menu_controller/get_menu_item_by_block',
            data: data,
            success: this.callback(success)
        });
    },

    get_menu_item: function(data, success){
        $.ajax({
            url: base_url+'admin/menu_controller/get_menu_item',
            data: data,
            success: this.callback(success)
        });
    },

    get_menu_item_for_parent: function(data, success){
        $.ajax({
            url: base_url+'admin/menu_controller/get_menu_item_for_parent',
            data: data,
            success: this.callback(success)
        });
    },

    delete_menu_item: function(data, success){
        $.ajax({
            url: base_url+'admin/menu_controller/delete_menu_item',
            data: data,
            success: this.callback(success)
        });
    }

}, {});