$.Model('Menu_item_model', {

    set_menu_item_relation: function(data, success, error){
        $.ajax({
            url: base_url+'admin/menu_controller/set_menu_item_relation',
            type: 'post',
            dataType: 'json',
            data: data,
            success: this.callback(success),
            cache: false,
            error: this.callback(error)
        });
    },

    set_menu_item: function(data, success, error){
        $.ajax({
            url: base_url+'admin/menu_controller/set_menu_item',
            type: 'post',
            dataType: 'json',
            data: data,
            success: this.callback(success),
            cache: false,
            error: this.callback(error)
        });
    },

    set_related_menu_item: function(data, success, error){
        $.ajax({
            url: base_url+'admin/menu_controller/set_related_menu_item',
            type: 'post',
            dataType: 'json',
            data: data,
            success: this.callback(success),
            cache: false,
            error: this.callback(error)
        });
    },

    get_menu_item: function(data, success, error){
        $.ajax({
            url: base_url+'admin/menu_controller/get_menu_item',
            type: 'post',
            dataType: 'json',
            data: data,
            success: this.callback(success),
            cache: false,
            error: this.callback(error)
        });
    },

    get_menu_item_for_parent: function(data, success, error){
        $.ajax({
            url: base_url+'admin/menu_controller/get_menu_item_for_parent',
            type: 'post',
            dataType: 'json',
            data: data,
            success: this.callback(success),
            cache: false,
            error: this.callback(error)
        });
    },

    get_menu_item_by_block: function(data, success, error){
        $.ajax({
            url: base_url+'admin/menu_controller/get_menu_item_by_block',
            type: 'post',
            dataType: 'json',
            data: data,
            success: this.callback(success),
            cache: false,
            error: this.callback(error)
        });
    },

    delete_menu_item: function(data, success, error){
        $.ajax({
            url: base_url+'admin/menu_controller/delete_menu_item',
            type: 'post',
            dataType: 'json',
            data: data,
            success: this.callback(success),
            cache: false,
            error: this.callback(error)
        });
    },

    minus_menu_item: function(data, success, error){
        $.ajax({
            url: base_url+'admin/menu_controller/minus_menu_item',
            type: 'post',
            dataType: 'json',
            data: data,
            success: this.callback(success),
            cache: false,
            error: this.callback(error)
        });
    },

    get_component_by_id: function(data, success, error){
        $.ajax({
            url: base_url+'admin/menu_controller/get_component_by_id',
            type: 'post',
            dataType: 'json',
            data: data,
            success: this.callback(success),
            cache: false,
            error: this.callback(error)
        });
    },

    disconect_menu_item: function(data, success, error) {
        $.ajax({
            url: base_url+'admin/component_controller/disconect_menu_item',
            type: 'post',
            dataType: 'json',
            data: data,
            success: this.callback(success),
            cache: false,
            error: this.callback(error)
        });
    }

}, {});