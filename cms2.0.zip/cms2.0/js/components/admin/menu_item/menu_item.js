steal(
    //then our component
    './css/menu_item.css',
    './controllers/menu_items_controller',
    './models/menu_items_model',
    './controllers/menu_item_controller',
    './models/menu_item_model'
    );









