steal('//components/admin/paginator/paginator.js')
.then(

    '//resources/plugins/jquery.synctranslit/jquery.synctranslit.js',

    'css/plugins/windows-engine/jquery.windows-engine.css',
    '//resources/plugins/jquery.windows-engine.js',


    '//resources/plugins/uploadify/jquery.uploadify.v2.1.4.js',
    '//resources/plugins/uploadify/uploadify.css',
    '//resources/plugins/uploadify/swfobject.js',

    //load resources
    './css/article.css',
    './controllers/articles_controller',
    './models/articles_model',
    './controllers/article_controller',
    './models/article_model',
    './models/article_seo_model'

);