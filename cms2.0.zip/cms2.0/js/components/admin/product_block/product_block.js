steal(
    '//resources/plugins/ckeditor/ckeditor.js',
    '//resources/plugins/jlinq/jlinq.js'
)
.then(

    './css/product_block.css',
    './controllers/product_blocks_controller',
    './models/product_blocks_model',
    './controllers/product_block_controller',
    './models/product_block_model'

    );