steal(
	'//css/admin/login.css',
	'./login_controller.js'
)