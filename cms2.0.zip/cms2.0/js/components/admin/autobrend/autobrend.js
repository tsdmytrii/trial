steal(

    '//resources/plugins/uploadify/jquery.uploadify.v2.1.4.js',
    '//resources/plugins/uploadify/swfobject.js',

    //load resources
    '//css/admin/static/static.css',
    './css/autobrend.css',
    './controllers/autobrend_controller',
    './models/autobrend_model'
    );


