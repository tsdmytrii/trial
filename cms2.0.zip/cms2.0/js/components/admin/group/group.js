steal(

    'css/plugins/windows-engine/jquery.windows-engine.css',
    '//resources/plugins/jquery.windows-engine.js',

    //load resources
    './css/group.css',

    './controllers/groups_controller',
    './models/groups_model',
    './controllers/group_controller',
    './models/group_model'

    );









