steal(
    'resources/plugins/ui/jquery-ui-1.8.16.custom.min.js',

    '//css/admin/menu/menu.css',

    '//resources/plugins/jquery-filetype/jquery-filetype.css',

    //load resources
    '//css/admin/static/static.css',
    './controllers/staticcomp_controller',
    './models/static_model'
    );









