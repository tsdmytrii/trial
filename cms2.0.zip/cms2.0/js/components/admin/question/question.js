steal(
    //load resources
    './css/question.css',

    './views/index.tmpl',
    './views/get_email.tmpl',
    './views/get_question_variant.tmpl',
    './views/set_email.tmpl',
    './views/set_question.tmpl',

    './controllers/question_controller',
    './models/question_model',

    './controllers/email_controller',
    './models/email_model',

    './controllers/question_variant_controller',
    './models/question_variant_model'
    );









