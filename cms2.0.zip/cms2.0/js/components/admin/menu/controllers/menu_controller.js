$.Controller.extend('Menu',{
    defaults: {
        viewpath:'//components/admin/menu/views/',
        wind_opt: {
            width: 475,
            height: 275,
            minimize: true,
            maximise: true,
            left: '100',
            top: '100',
            resize: true,
            status_bar: true,
            modal: true
        },
        lang_id: 2,
        pref: 'ru'
    }

},{
    init:function(){

        this.elementId = this.element.attr('id');

        var html = $.View(this.Class.defaults.viewpath+'index.tmpl', {});

        this.element.html(html);

        this.loadMenuBlock();

    },

    /*
     * Load menu block
     */

    loadMenuBlock: function(id){

        Menu_model.get_all_menu_blocks(this.callback('menuBlocksGeted'));

    },

    menuBlocksGeted: function(data){

        if (data && data.message) {
            show_error('Код ошибки: '+data.message);
        } else {
            var html = $.View(this.Class.defaults.viewpath+'get_menu_block.tmpl', {
                our_data: data.data,
                base_url: base_url
            });

            $('#menuBlockContent').html(html);
        }

        componentLoaded(this.element);

    },

    /*
     * SET menu block
     */

    '#addMenuBlock click': function(){

        this.setMenuBlockCallback(false);

    },

    '.editMenuBlock click': function(el){
        var id = {
            menu_block_id: $(el).parents(".menu_block_icon_wrap").data('menu_block_id')
        };

        Menu_model.get_menu_block(id, this.callback('setMenuBlockCallback'));
    },

    setMenuBlockCallback: function(data){

        if (data && data.message) {
            show_error('Код ошибки: '+data.message);
            return;
        }

        var html = $.View(this.Class.defaults.viewpath+'set_menu_block.tmpl', {
                our_data: data ? data.data : false
            }),
            msg = data ? 'Изменения меню блока' : 'Добавления меню блока';

        loadWindow('set_menu_block', this.Class.defaults.wind_opt, msg, html);

        $('#set_menu_block_window').menu_block({
            data: data ? data.data : false,
            elementId: this.elementId
        });

    },

    /*
     * DELETE menu block
     */

    '.deleteMenuBlock click': function(el){
        var id = {
            menu_block_id: $(el).parents(".menu_block_icon_wrap").data('menu_block_id')
        };

        if(confirm('Вы действительно хотите удалить этот блок? Это приведет к удалению целого раздела.')){
            Menu_model.delete_menu_block(id, this.callback('menuBlockDeleted', el));
        }
    },

    menuBlockDeleted: function(el, data){

        if (data.success) {

            if (data.message) {
                show_error('Код ошибки: '+data.message);
                return;
            }

            show_success('Операция удаления успешна!');

            var tr = el.parents('tr');

            tr.slideUp(300, function(){
                tr.remove();
            });

        } else
            show_error('Ошибка');


    }

}
);