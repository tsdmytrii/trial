$.Model('Menu_block_model', {

    set_menu_block: function(data, success) {
        $.ajax({
            url: base_url+'admin/menu_controller/set_menu_block',
            data: data,
            success: this.callback(success)
        });
    }

}, {});