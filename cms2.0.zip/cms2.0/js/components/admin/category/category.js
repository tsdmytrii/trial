steal(
    '//resources/plugins/ckeditor/ckeditor.js',
    '//resources/plugins/jlinq/jlinq.js',
    '//resources/plugins/uploadify/jquery.uploadify.v2.1.4.js',
    '//resources/plugins/uploadify/swfobject.js'
)
.then(

    './css/category.css',
    './controllers/category_controller',
    './models/category_model',
    './controllers/categories_controller',
    './models/categories_model'

    );