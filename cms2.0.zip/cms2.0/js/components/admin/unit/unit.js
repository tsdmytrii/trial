steal(

    'css/plugins/windows-engine/jquery.windows-engine.css',
    '//resources/plugins/jquery.windows-engine.js',

    //load resources
    './css/unit.css',

    './controllers/units_controller',
    './models/units_model',
    './controllers/unit_controller',
    './models/unit_model'

    );









