steal(
    //load resources
    './css/marking.css',
    './controllers/marking_controller',
    './models/marking_model'
    );









