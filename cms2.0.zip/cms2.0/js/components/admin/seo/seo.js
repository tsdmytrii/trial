steal(
    '//resources/plugins/jquery.validate.js',
    './css/seo.css',
    './controllers/seo_controller',
    './models/seo_model'
    );