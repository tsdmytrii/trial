steal(
	'./controllers/navigation_controller.js',
	'./models/navigation_model.js'
);