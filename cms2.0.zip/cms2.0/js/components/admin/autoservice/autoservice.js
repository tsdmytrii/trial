steal(
    'resources/plugins/ui/jquery-ui-1.8.16.custom.min.js',

    '//resources/plugins/uploadify/jquery.uploadify.v2.1.4.js',
    '//resources/plugins/uploadify/swfobject.js',

    '//resources/plugins/jquery.dragsort-0.5.1.min.js',

    '//css/admin/menu/menu.css',

    '//css/admin/static/static.css',

    //load resources
    '//css/admin/autoservice/autoservice.css',
    './controllers/autoservice_controller',
    './models/autoservice_model'
    );









