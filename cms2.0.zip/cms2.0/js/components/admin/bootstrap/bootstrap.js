steal(
	'//resources/packages/css/bootstrap.css',
	'//resources/packages/js/bootstrap.js'
);