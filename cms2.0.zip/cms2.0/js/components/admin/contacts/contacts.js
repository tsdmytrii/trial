steal(
    'resources/plugins/ui/jquery-ui-1.8.16.custom.min.js',

    '//css/admin/menu/menu.css',

    //load resources
    '//css/admin/contacts/contacts.css',
    './controllers/contacts_controller',
    './models/contacts_model'
    );









