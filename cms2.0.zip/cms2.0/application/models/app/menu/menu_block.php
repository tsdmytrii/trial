<?php

class Menu_block extends DataMapper {

    public $db_params = 'default';
    public $table = 'menu_blocks';
    public $has_many = array('menu_item');
    public static $ci;
    public $validation = array(
        array(
            'field' => 'id',
            'label' => 'id',
            'rules' => array('trim', 'numeric', 'max_length' => 5),
        ),
        array(
            'field' => 'name',
            'label' => 'Name',
            'rules' => array('trim', 'min_length' => 3, 'required', 'max_length' => 100),
        )
    );

    function __construct($id = NULL) {
        parent::__construct($id);
        if (empty(self::$ci)) {
            self::$ci = &get_instance();
        }
    }

    public function set_menu_block() {
        if (self::$ci->access->check_access(__FUNCTION__) == false)
            return 403;

        $menu_block = new Menu_block();

        if (self::$ci->input->post('id')) {
            $menu_block->get_by_id(self::$ci->input->post('id'));
        }

        $menu_block->name = self::$ci->input->post('name');
        $menu_block->position = self::$ci->input->post('position');

        if ($menu_block->save())
            return $menu_block->to_array();
        else
            return false;
    }

    public function get_menu_block($menu_block_id = false) {
        if (self::$ci->access->check_access(__FUNCTION__) == false)
            return 403;

        $menu_block_id = self::$ci->input->post('menu_block_id') ? self::$ci->input->post('menu_block_id') : $menu_block_id;

        if ($menu_block_id) {

            $menu_block = new Menu_block();

            return $menu_block->get_by_id($menu_block_id)->to_array();

        } else
            return false;

    }

    public function get_all_menu_blocks() {
        if (self::$ci->access->check_access(__FUNCTION__) == false)
            return 403;

        $menu_block = new Menu_block();

        return $menu_block->order_by("position")->get()->all_to_array();
    }

    public function get_footer() {
//        $menu_block_id = self::$ci->input->post('menu_block_id') ? self::$ci->input->post('menu_block_id') : false;
        $menu_block_id = 4;

        $menu_item = new Menu_item();

        $result = $menu_item->get_menu_item_by_block($menu_block_id);

        return $result;
    }

    public function delete_menu_block() {
        if (self::$ci->access->check_access(__FUNCTION__) == false)
            return 403;

        $menu_block_id = self::$ci->input->post('menu_block_id');

        $menu_block = new Menu_block();

        $menu_block->get_by_id($menu_block_id);

        return $menu_block->delete() ? array('menu_block_id' => $menu_block_id) : false;
    }

}

?>