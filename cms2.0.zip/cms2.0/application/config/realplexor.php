<?
$config['host'] = '127.0.0.1';
$config['port'] = '10010';
$config['namespace'] = null;
$config['identifier'] = 'identifier';
?>