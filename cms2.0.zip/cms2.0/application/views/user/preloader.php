<div id="preloader" style="position: fixed; width: 100%; height: 100%; top: 0; left: 0; right: 0; bottom: 0; background-color: #d1d1d1; z-index: 999;">
    <img src="<?= base_url(); ?>js/images/preloader.gif" style="position: fixed; top: 48.5%; left: 49.5%;"/>
</div>