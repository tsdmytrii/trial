<img src="<?= base_url();?>js/images/logo.png" id="logoAC">

<div id="mainMenu">
    <?php foreach($header as $key => $h):?>
         <?php if ($h['parent_id'] == 0): ?>
            <?php if (isset($h['lang'][$pref])): ?>
                <?php
                    if (isset($h['link']) && isset($h['link'][$pref]['link'])){
                        $link = base_url() . $lang_pref . $h['link'][$pref]['link'];
                    } else if (isset($h["href"]) && $h['href'] !== '') {
                        $link = base_url() . $lang_pref . $h['href'] . '/' . $h['id'] . '/' . $h['main'] . '/' . $lang_id;
                    } else {
                        $link = base_url() . $lang_pref . '#';
                    }

                    if (intval($h['component_type_id']) == 26) {
                        $automodels_link = $link;
                        $automodels_title = $h['lang'][$pref]['value'];
                    }
                ?>
                <?php if (intval($h['component_type_id']) !== 28):?>
                    <a class="menuItem new_component" title="<?= $h['lang'][$pref]['value']?>" href="<?= $link;?>/"><?= $h['lang'][$pref]['value']?></a>
                <?php endif;?>

                <?php if (count($header) != ($key+2) && count($header) != ($key+1)):?>
                    <img src="<?= base_url();?>js/images/menu_sep.png" class="menuSep" />
                <?php endif;?>
            <?php endif;?>
        <?php endif;?>
    <?php endforeach;?>
</div>

<table id="otherLinks">
    <tr>
        <td>
            <a class="otherLink" target="_blank" href="http://www.mercedes-benz.ua/">
                <img src="<?= base_url();?>js/images/mercedes.jpg"/>
            </a>
            <a class="otherLink" target="_blank" href="http://www.chrysler.ua/">
                <img src="<?= base_url();?>js/images/chrysler.jpg"/>
            </a>
            <a class="otherLink" target="_blank" href="http://www.jeep.ua/">
                <img src="<?= base_url();?>js/images/jeep.jpg"/>
            </a>
            <a class="otherLink" target="_blank" href="http://www.dodge.com.ua/">
                <img src="<?= base_url();?>js/images/dodge.jpg"/>
            </a>
            <a class="otherLink" target="_blank" href="http://ducati-kiev.com/">
                <img src="<?= base_url();?>js/images/ducatti.jpg"/>
            </a>
        </td>
    </tr>
</table>

<div id="linkUs">

    <?php foreach($header as $key => $h):?>
         <?php if ($h['parent_id'] == 0): ?>
            <?php if (isset($h['lang'][$pref])): ?>
                <?php
                    if (isset($h['link']) && isset($h['link'][$pref]['link'])){
                        $link = base_url() . $lang_pref . $h['link'][$pref]['link'];
                    } else if (isset($h["href"]) && $h['href'] !== '') {
                        $link = base_url() . $lang_pref . $h['href'] . '/' . $h['id'] . '/' . $h['main'] . '/' . $lang_id;
                    } else {
                        $link = base_url() . $lang_pref . '#';
                    }
                ?>
                <?php if (intval($h['component_type_id']) === 28):?>
                    <div class="linkUs phoneNumber">
                        <a class="popUp new_component" title="<?= $h['lang'][$pref]['value']?>" href="<?= $link;?>/">
                            (044) 206-32-00 (044) 451-45-37
                            <div class='clear'></div>
                            г. Киев пр. Московский, 22
                        </a>
                    </div>
                <?php endif;?>

            <?php endif;?>
        <?php endif;?>
    <?php endforeach;?>
    <div class="linkUs">
        <a class="popUp" href="<?= base_url();?>"><img src="<?= base_url();?>js/images/search.gif"/></a>
    </div>
</div>

<div id="windTopMax"></div>
<div id="headerBtmBg"></div>
