<div id="windBottomMax"></div>

<div id="button_panel"></div>

<a id="copyRight" href="http://webinnovativelab.com" target="_blank"><img src="<?= base_url();?>js/images/wil_logo.png"/> WEB-INNOVATIVE LAB</a>