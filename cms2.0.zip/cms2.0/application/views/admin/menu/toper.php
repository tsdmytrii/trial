<script type="text/javascript">
    var component_types;
    steal('components/admin/core')
    .then('components/admin/menu')
    .then(function(){
        $('body').menu();
    });
</script>
</head>
<body>