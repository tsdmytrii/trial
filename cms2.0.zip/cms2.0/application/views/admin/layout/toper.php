<script type="text/javascript">
    var component_types;
    steal('components/admin/core')
    .then('components/admin/layout')
    .then(function(){
        $('body').layout();
    });
</script>
</head>
<body>