<div id="preLoad" class="preload_wrapper">
    <div class="preload"></div>
    <div class="progress progress-black progress-striped active">
        <div class="bar" style="width:100%"></div>
    </div>
</div>

<div id="content" class="container-fluid">

    <div class="hero-unit" id="content_wrapper">

        <div class="row-fluid">

            <div id="work_space" class="span12">

                <ul id="tab_navigation" class="nav nav-tabs" ></ul>

                <div class="clear"></div>

                <div id="tab_container">
                    <div id="preLoadComp" class="preload_wrapper">
                        <div class="preload"></div>
                        <div class="progress progress-black progress-striped active">
                            <div class="bar" style="width:100%"></div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>
    <ul id="tab_navigation"></ul>

</div>