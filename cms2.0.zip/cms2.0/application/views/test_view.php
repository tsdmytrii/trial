<!DOCTYPE html>
<html lang="en">
    <head>
        <meta content="text/html; charset=UTF-8" http-equiv="content-type" />
        <title>Test new db controller</title>
    </head>
    <body>
        <?php print_r($data);?>
        Test new db controller
    </body>
</html>