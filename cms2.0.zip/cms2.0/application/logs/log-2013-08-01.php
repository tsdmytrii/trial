<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-08-01 13:29:57 --> {"type":"success","filename":"8117b4746050740a2cd14774b398163e9eda1885.jpg","width":910,"height":494}
ERROR - 2013-08-01 13:44:26 --> {"type":"success","filename":"40d2f182a21f07401f45520cfae5d99f3992c4c1.jpg","width":910,"height":494}
ERROR - 2013-08-01 13:46:17 --> {"type":"success","filename":"b387f4a8af0ff442f9ec674d4a1ad981735968cc.jpg","width":2560,"height":1440}
ERROR - 2013-08-01 13:49:49 --> {"type":"success","filename":"fceb826962b947a1c16d8577b1480802772d2abf.jpg","width":910,"height":494}
ERROR - 2013-08-01 13:51:59 --> {"type":"success","filename":"3025e1ef11a5028fbbd662934a6c062077700340.jpg","width":910,"height":494}
ERROR - 2013-08-01 13:52:13 --> {"type":"success","filename":"f75df15918f3e6f4bfe28f3fe7e0b6b0b5815ef6.jpg","width":2560,"height":1440}
