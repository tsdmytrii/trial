<?php
    $localization = array(
        'registration' => array(
            'registration' => 'Registrieren',
            'email' => 'Email',
            'email_conf' => 'Email wiederholen',
            'password_conf' => 'Passwort wiederholen',
        ),
        'login' => array(
            'username' => 'Benutzername',
            'password' => 'Passwort',
            'password_forget' => 'Passwort vergessen'
        )
    );
?>
